import { useEffect, useRef, useState } from 'react'
import './Camera.css'

export default function Camera() {
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const [cameraState, setCameraState] = useState('idle')
  const [errorMessage, setErrorMessage] = useState('')
  const [filter, setFilter] = useState('dreamy')

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((track) => track.stop())
    }
  }, [])

  async function startCamera() {
    setErrorMessage('')
    if (!navigator.mediaDevices?.getUserMedia) {
      setErrorMessage('Kameran stöds inte här. Öppna appen via en säker HTTPS-adress.')
      setCameraState('error')
      return
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' },
        audio: false
      })
      streamRef.current = stream
      if (videoRef.current) videoRef.current.srcObject = stream
      setCameraState('live')
    } catch {
      setErrorMessage('Vi kunde inte öppna kameran. Kontrollera webbläsarens kameratillstånd.')
      setCameraState('error')
    }
  }

  function stopCamera() {
    streamRef.current?.getTracks().forEach((track) => track.stop())
    streamRef.current = null
    if (videoRef.current) videoRef.current.srcObject = null
    setCameraState('idle')
  }

  return (
    <section className="page camera-page">
      <p className="eyebrow">LITE MAGI, TACK</p>
      <h1>Fånga <span>ögonblicket.</span></h1>
      <p className="page-intro">Kameran är redo när du är det.</p>

      <div className={`camera-frame filter-${filter}`}>
        {cameraState === 'live' ? (
          <video ref={videoRef} autoPlay playsInline muted className="camera-video" />
        ) : (
          <div className="camera-placeholder">
            <span className="camera-symbol">◎</span>
            <strong>Din kamera väntar</strong>
            <small>Din bild stannar i den här förhandsversionen.</small>
          </div>
        )}
        <span className="camera-corner corner-tl" />
        <span className="camera-corner corner-tr" />
        <span className="camera-corner corner-bl" />
        <span className="camera-corner corner-br" />
        {cameraState === 'live' && <span className="live-label"><span /> LIVE</span>}
      </div>

      <div className="filter-picker">
        <p className="eyebrow">VÄLJ EN KÄNSLA</p>
        <div className="filter-options">
          {[
            { id: 'dreamy', label: 'Dreamy', symbol: '✦' },
            { id: 'pink', label: 'Pink pop', symbol: '♡' },
            { id: 'mono', label: 'No filter', symbol: '◐' }
          ].map((item) => (
            <button key={item.id} className={`filter-chip ${filter === item.id ? 'selected' : ''}`} onClick={() => setFilter(item.id)}>
              <span>{item.symbol}</span>{item.label}
            </button>
          ))}
        </div>
        <p className="filter-disclaimer">Det här är färgförhandsvisningar. Riktiga ansiktsdeformationer lägger vi till senare.</p>
      </div>

      {errorMessage && <p className="camera-error" role="alert">{errorMessage}</p>}

      {cameraState === 'live' ? (
        <button className="primary-button" onClick={stopCamera}>Stäng kameran</button>
      ) : (
        <button className="primary-button" onClick={startCamera}>Öppna kameran <span>↗</span></button>
      )}
      <p className="privacy-note">Kameran startar bara när du trycker på knappen.</p>
    </section>
  )
}
