import { useState } from 'react'
import Home from './Home.jsx'
import Camera from './Camera.jsx'
import Chat from './Chat.jsx'
import './App.css'

const tabs = [
  { id: 'home', label: 'Hem', icon: '⌂' },
  { id: 'camera', label: 'Kamera', icon: '◎' },
  { id: 'chat', label: 'Chatt', icon: '♡' },
]

export default function App() {
  const [activeTab, setActiveTab] = useState('home')

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={(event) => { event.preventDefault(); setActiveTab('home') }}>
          <span className="brand-mark">✳</span>
          <span>PLOT <em>TWIST</em></span>
        </a>
        <button className="avatar-button" aria-label="Profil">✦</button>
      </header>

      <main className="main-content">
        <div hidden={activeTab !== 'home'}><Home onOpenCamera={() => setActiveTab('camera')} onOpenChat={() => setActiveTab('chat')} /></div>
        <div hidden={activeTab !== 'camera'}><Camera /></div>
        <div hidden={activeTab !== 'chat'}><Chat /></div>
      </main>

      <nav className="bottom-nav" aria-label="Huvudnavigation">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={`nav-item ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
            aria-current={activeTab === tab.id ? 'page' : undefined}
          >
            <span className="nav-icon">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
